import pg from "pg";
import "dotenv/config"; 

const { Pool } = pg;

// 1. Determina si el entorno es 'local' o 'produccion'
// Puedes añadir esta variable al archivo .env (ENVIRONMENT=local)
const isLocal = process.env.ENVIRONMENT === 'local';

// 2. Define la configuración de SSL
const sslConfig = isLocal ? false : { rejectUnauthorized: false };

export const pool = new Pool({
  connectionString: process.env.DATA_BASEURL,
  // 3. Usa la configuración condicional:
  ssl: sslConfig, 
});