import "dotenv/config";
import express from "express";
import cors from "cors";
import { pool } from "./db.js";
import usuariosRoutes from "./routes/usuarios.routes.js";
import otRoutes from "./routes/ot.routes.js";
import comentariosRoutes from "./routes/comentarios.routes.js";
import auditoriasRoutes from "./routes/auditorias.routes.js";
import authRoutes from './routes/auth.routes.js'; 
import { fileURLToPath } from "url";
import path from "path";
import cookieParser from "cookie-parser"; 

const app = express();

// CONFIGURACIÓN DE CORS
const corsOptions = {
    // 💡 CORRECCIÓN: Define explícitamente el puerto de tu Frontend (Vite)
    origin: 'http://localhost:5173', 
    credentials: true, 
    methods: 'GET,HEAD,PUT,PATCH,POST,DELETE',
    allowedHeaders: 'Content-Type, Authorization',
    exposedHeaders: ['Set-Cookie'], 
};

// crear constante de conexion e importacion
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// MIDDLEWARES PRINCIPALES
app.use(express.json()); 
app.use(cookieParser()); 
app.use(cors(corsOptions)); 

// REGISTRO DE RUTAS DE API
app.use("/api/usuarios", usuariosRoutes);
app.use("/api/ot", otRoutes);
app.use("/api/comentarios", comentariosRoutes);
app.use("/api/auditorias", auditoriasRoutes);
app.use("/api/auth", authRoutes); 

const PORT = process.env.PORT || 4000;

app.listen(PORT, () => {
    console.log("Backend corriendo en puerto", PORT);
});
// Test conexión a BD
pool.query("SELECT NOW()", (err, result) => {
    if (err) {
        console.error("❌ Error conectando a la BD:", err);
    } else {
        console.log("✅ Conexión a BD OK:", result.rows[0]);
    }
});