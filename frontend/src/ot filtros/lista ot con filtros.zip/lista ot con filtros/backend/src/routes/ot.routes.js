import { Router } from "express"; // 🛑 Solución 1: Importa Router
import { pool } from "../db.js";
import { generarCodigoOT } from "../utils/generarCodigoOT.js";
// import { authRequired } from '../midlewares/auth.middleware.js'; 

const router = Router(); // 🛑 Solución 2: Inicializa el router

// Crear OT
router.post("/", /*authRequired,*/ async (req, res) => {
    const { titulo, descripcion, estado, fecha_inicio_contrato, fecha_fin_contrato, responsable_id } = req.body;
    const codigo = generarCodigoOT();

    try {
        const result = await pool.query(
            `INSERT INTO ot (codigo, titulo, descripcion, estado, fecha_inicio_contrato, fecha_fin_contrato, responsable_id)
             VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *`,
            [codigo, titulo, descripcion, estado, fecha_inicio_contrato, fecha_fin_contrato, responsable_id]
        );

        res.json(result.rows[0]);
    } catch (error) {
        console.error("Error al crear OT:", error);
        res.status(500).json({ message: "Error interno al crear la OT." });
    }
});

// Listar OT con Filtros y JOIN
router.get("/", /*authRequired,*/ async (req, res) => {
    const { estado, responsable_id, nombre_cliente_codigo, fechaDesde, fechaHasta } = req.query;

    // Se incluye el JOIN para obtener el nombre del usuario responsable
    let query = `
        SELECT 
            ot.*, 
            u.nombre AS nombre_responsable 
        FROM ot
        INNER JOIN usuarios u ON ot.responsable_id = u.id_usuario 
        WHERE 1=1
    `;
    let params = [];
    let paramIndex = 1;

    // Aplicar Filtros Condicionales
    if (estado && estado !== 'Todos') {
        query += ` AND estado = $${paramIndex++}`;
        params.push(estado);
    }
    
    if (responsable_id && responsable_id !== 'Todos') {
        query += ` AND ot.responsable_id = $${paramIndex++}`;
        params.push(responsable_id);
    }

    if (nombre_cliente_codigo) {
        query += ` AND (titulo ILIKE $${paramIndex++} OR codigo ILIKE $${paramIndex++})`;
        params.push(`%${nombre_cliente_codigo}%`);
        params.push(`%${nombre_cliente_codigo}%`);
    }

    if (fechaDesde) {
        query += ` AND fecha_inicio_contrato >= $${paramIndex++}`;
        params.push(fechaDesde);
    }

    if (fechaHasta) {
        query += ` AND fecha_inicio_contrato <= $${paramIndex++}`;
        params.push(fechaHasta);
    }

    query += " ORDER BY id_ot DESC";

    try {
        const result = await pool.query(query, params);
        res.json(result.rows);
    } catch (error) {
        console.error("Error al listar OT con filtros y JOIN:", error);
        res.status(500).json({ message: "Error interno al listar OTs." });
    }
});

export default router;