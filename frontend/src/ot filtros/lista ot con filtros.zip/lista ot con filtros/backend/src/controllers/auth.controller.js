import { pool } from '../db.js'; 
import bcrypt from 'bcryptjs';     
import jwt from 'jsonwebtoken';    

const JWT_SECRET = process.env.JWT_SECRET || 'clave_secreta_fuerte'; 

const createAccessToken = (payload) => {
    return jwt.sign(payload, JWT_SECRET, { expiresIn: '1d' }); 
};

export const login = async (req, res) => {
    const { correo, password } = req.body;

    try {
        // Criterio 2: Verificar credenciales en PostgreSQL
        const result = await pool.query('SELECT * FROM usuarios WHERE correo = $1', [correo]);
        
        if (result.rows.length === 0) {
            // Criterio 4: Credenciales inválidas
            return res.status(401).json({ message: 'Credenciales inválidas (Usuario no encontrado)' });
        }

        const user = result.rows[0];

        const isMatch = await bcrypt.compare(password, user.password);

        if (!isMatch) {
            // Criterio 4: Credenciales inválidas
            return res.status(401).json({ message: 'Credenciales inválidas (Contraseña incorrecta)' });
        }

        // Criterio 3: Generar el token JWT
        const token = createAccessToken({ id: user.id, rol: user.rol });

        // Configuración de la cookie para DESARROLLO LOCAL
        res.cookie('token', token, {
            httpOnly: true, 
            maxAge: 24 * 60 * 60 * 1000 
        });

        return res.json({
            id: user.id,
            nombre: user.nombre,
            rol: user.rol,
            token: token 
        });

    } catch (error) {
        return res.status(500).json({ message: 'Error interno del servidor durante la autenticación' });
    }
};

export const logout = (req, res) => {
    // Criterio 5: Eliminar el token
    res.cookie('token', '', { expires: new Date(0) });
    return res.sendStatus(200);
};