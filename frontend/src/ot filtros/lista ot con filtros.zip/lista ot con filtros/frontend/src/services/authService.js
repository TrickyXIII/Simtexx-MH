// services/authService.js

// Apuntamos al backend local para desarrollo
const BASE_URL = "http://localhost:4000"; 
const AUTH_URL = `${BASE_URL}/api/auth`; 

export const loginUser = async (correo, password) => {
    const response = await fetch(`${AUTH_URL}/login`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ correo, password }),
        credentials: 'include', // CRÍTICO para enviar la cookie
    });

    if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Error de autenticación');
    }

    const data = await response.json();
    
    // Almacenamiento local del usuario
    localStorage.setItem('usuarioActual', JSON.stringify({
        id: data.id,
        nombre: data.nombre,
        rol: data.rol,
    }));
    
    return data; 
};

export const logoutUser = async () => {
    await fetch(`${AUTH_URL}/logout`, { 
        method: 'POST',
        credentials: 'include' 
    }); 
    localStorage.removeItem('usuarioActual'); 
};