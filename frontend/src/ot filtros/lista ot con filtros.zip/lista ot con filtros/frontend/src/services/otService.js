// services/otService.js

const BASE_URL = "http://localhost:4000"; 
const OT_URL = `${BASE_URL}/api/ot`; 

// --- FUNCIÓN DE AYUDA PARA CONSTRUIR LA QUERY STRING ---
const buildQueryString = (params) => {
    const query = new URLSearchParams();
    for (const key in params) {
        // Solo agrega el parámetro si tiene un valor y no es 'Todos' (para evitar enviar filtros vacíos)
        if (params[key] && params[key] !== 'Todos') {
            query.append(key, params[key]);
        }
    }
    return query.toString();
};

export const createOT = async (ot) => {
    // ... (El código de createOT se mantiene igual) ...
    try {
        const response = await fetch(OT_URL, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify(ot), 
        });

        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.message || `Error ${response.status}: Fallo al crear la OT.`);
        }
        return await response.json(); 

    } catch (error) {
        console.error("Fallo la llamada a la API para crear OT:", error);
        throw new Error("No se pudo conectar al servidor."); 
    }
}

// --- FUNCIÓN getOTs MODIFICADA PARA ACEPTAR FILTROS ---
export const getOTs = async (filtros = {}) => { // Acepta un objeto 'filtros' (por defecto vacío)
    try {
        const queryString = buildQueryString(filtros);
        
        // Construye la URL final: /api/ot?estado=Pendiente&fechaDesde=...
        const finalUrl = `${OT_URL}?${queryString}`; 
        
        const response = await fetch(finalUrl);
        
        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.message || `Error ${response.status}: Fallo al obtener las OTs.`);
        }
        return await response.json(); 
        
    } catch (error) {
        console.error("Fallo la llamada a la API para obtener OTs:", error);
        // Devolvemos un arreglo vacío para que el Front-end no falle
        return []; 
    }
}
// ... (Tus otras funciones no implementadas) ...
export function getOTById() { console.warn("getOTById no implementada para API"); return null; }
export function updateOT() { console.warn("updateOT no implementada para API"); }
export function saveOTs() { console.warn("saveOTs no implementada para API"); }
export function deleteOT() { console.warn("deleteOT no implementada para API"); }