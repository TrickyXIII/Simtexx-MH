import { useState } from "react";
import { createOT } from "../services/otService";
import Footer from "../components/Footer";
import NavBar from "../components/NavBar";
import "./CrearOT.css";
import { useNavigate } from "react-router-dom"; 

export default function CrearOT() {
    const [errors, setErrors] = useState({});
    const navigate = useNavigate();
    
    // NOMBRES DE ESTADO para coincidir con el Back-end
    const [form, setForm] = useState({
        titulo: "", 
        descripcion: "",
        estado: "",
        cliente: "", // Usado solo en Front-end 
        responsable: "", // Contendrá el ID del responsable
        fecha_inicio_contrato: "", 
        fecha_fin_contrato: "", 
    });
    
    // Datos de ejemplo para los dropdowns
    const estados = ["Pendiente", "En Proceso", "Finalizada"];
    const clientes = [
        { id: '1', nombre: 'Juan Perez' },
        { id: '2', nombre: 'Empresa X' }
    ];
    const responsables = [
        { id: 3003, nombre: 'Maria Lopez (3003)' },
        { id: 1010, nombre: 'Pedro Rojas (1010)' }
    ];


    const handleChange = (e) => {
        setForm({ ...form, [e.target.name]: e.target.value });
    };

    const validateForm = () => {
        const newErrors = {};

        if (!form.titulo.trim()) newErrors.titulo = "El título es obligatorio";
        if (!form.descripcion.trim()) newErrors.descripcion = "La descripción es obligatoria";
        if (!form.estado) newErrors.estado = "Debe seleccionar un estado";
        if (!form.cliente) newErrors.cliente = "Debe seleccionar un cliente";
        if (!form.responsable) newErrors.responsable = "Debe seleccionar un responsable";
        if (!form.fecha_inicio_contrato) newErrors.fecha_inicio_contrato = "Debe ingresar fecha de inicio";
        if (!form.fecha_fin_contrato) newErrors.fecha_fin_contrato = "Debe ingresar fecha de finalización";

        return newErrors;
    };

    const handleSubmit = async (e) => { 
        e.preventDefault();

        const validation = validateForm();
        if (Object.keys(validation).length > 0) {
            setErrors(validation);
            return;
        }

        setErrors({}); 

        const newOT = {
            titulo: form.titulo,
            descripcion: form.descripcion,
            estado: form.estado,
            // Aseguramos que el ID del responsable sea un número para el Back-end
            responsable_id: parseInt(form.responsable), 
            fecha_inicio_contrato: form.fecha_inicio_contrato,
            fecha_fin_contrato: form.fecha_fin_contrato,
            
            historial: [{ fecha: new Date().toLocaleDateString(), msg: "OT creada" }],
        };

        try {
            await createOT(newOT); 
            console.log("OT creada con éxito en el backend.");
            alert("OT creada con éxito"); 
            navigate('/listaot'); // Navegar a la lista después de la creación
        } catch (error) {
            console.error("Error al guardar la OT en el servidor:", error);
            alert("Error: No se pudo conectar al servidor.");
        }
    };
    
    return (
        <>
            <NavBar />

            <div className="container-crearot">
                <h2>Crear Orden de Trabajo</h2>
                <h4>Simtexx Spa</h4>

                <form className="form-box" onSubmit={handleSubmit}>

                    {/* CAMPO TÍTULO */}
                    <input
                        type="text"
                        name="titulo"
                        placeholder="Título"
                        value={form.titulo}
                        onChange={handleChange}
                    />
                    {errors.titulo && <p className="error">{errors.titulo}</p>}

                    {/* CAMPO DESCRIPCIÓN */}
                    <textarea
                        name="descripcion"
                        placeholder="Descripción"
                        value={form.descripcion}
                        onChange={handleChange}
                    />
                    {errors.descripcion && <p className="error">{errors.descripcion}</p>}

                    {/* CAMPO ESTADO */}
                    <select name="estado" value={form.estado} onChange={handleChange}>
                        <option value="">Estado</option>
                        {estados.map(estado => (
                            <option key={estado} value={estado}>{estado}</option>
                        ))}
                    </select>
                    {errors.estado && <p className="error">{errors.estado}</p>}

                    {/* CAMPO CLIENTE */}
                    <select name="cliente" value={form.cliente} onChange={handleChange}>
                        <option value="">Cliente</option>
                        {clientes.map(cliente => (
                            <option key={cliente.id} value={cliente.id}>{cliente.nombre}</option>
                        ))}
                    </select>
                    {errors.cliente && <p className="error">{errors.cliente}</p>}

                    {/* CAMPO RESPONSABLE */}
                    <select
                        name="responsable"
                        value={form.responsable}
                        onChange={handleChange}
                    >
                        <option value="">Responsable</option>
                        {responsables.map(r => (
                            <option key={r.id} value={r.id}>{r.nombre}</option>
                        ))}
                    </select>
                    {errors.responsable && <p className="error">{errors.responsable}</p>}

                    {/* CAMPO FECHA INICIO */}
                    <label>Fecha inicio de contrato</label>
                    <input 
                        type="date" 
                        name="fecha_inicio_contrato" 
                        value={form.fecha_inicio_contrato} 
                        onChange={handleChange} 
                    />
                    {errors.fecha_inicio_contrato && <p className="error">{errors.fecha_inicio_contrato}</p>}

                    {/* CAMPO FECHA FIN */}
                    <label>Fecha finalización de contrato</label>
                    <input 
                        type="date" 
                        name="fecha_fin_contrato" 
                        value={form.fecha_fin_contrato} 
                        onChange={handleChange} 
                    />
                    {errors.fecha_fin_contrato && <p className="error">{errors.fecha_fin_contrato}</p>}

                    <button className="btn-rojo" type="submit" >Crear OT</button>
                    <button className="btn-cancelar" type="button" onClick={() => navigate(-1)}>
                        Cancelar
                    </button>
                </form>
            </div>

            <Footer />
        </>
    );
}