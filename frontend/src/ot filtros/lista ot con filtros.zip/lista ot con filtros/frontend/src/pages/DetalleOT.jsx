import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
// Asumimos que getOTById ya está implementado correctamente para ser async
import { getOTById } from "../services/otService"; 
import Footer from "../components/Footer";
import NavBar from "../components/NavBar";
import "./DetalleOT.css";

export default function DetalleOT() {
  const { id } = useParams();
  const navigate = useNavigate();
  
  // 💡 ESTADOS PARA MANEJAR LA CARGA ASÍNCRONA
  const [ot, setOt] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  
  // 💡 CARGA ASÍNCRONA DE DATOS
  useEffect(() => {
    const loadOt = async () => {
      setLoading(true);
      setError(null);
      try {
        const data = await getOTById(id);
        // La OT debe tener el historial y los comentarios para que el render funcione
        setOt(data);
      } catch (err) {
        console.error("Error al cargar OT:", err);
        setError("Error al cargar la Orden de Trabajo. Verifique la conexión.");
      } finally {
        setLoading(false);
      }
    };
    loadOt();
  }, [id]);

  // Se mueve la obtención del usuario aquí para que sea más claro
  const usuario = JSON.parse(localStorage.getItem("usuarioActual"));

  // --- Renderizados Condicionales ---
  if (loading) {
    return (
      <>
        <NavBar />
        <div className="detalle-container" style={{ textAlign: 'center', padding: '50px' }}>
          <h2>Cargando Orden de Trabajo {id}...</h2>
        </div>
        <Footer />
      </>
    );
  }

  if (error) {
    return (
      <>
        <NavBar />
        <div className="detalle-container" style={{ textAlign: 'center', padding: '50px', color: 'red' }}>
          <h2>{error}</h2>
        </div>
        <Footer />
      </>
    );
  }

  if (!ot) return <h2>OT no encontrada</h2>;


  // --- Renderizado de Detalle (solo se ejecuta si ot tiene datos) ---
  return (
    <>
      <NavBar />

      <div className="detalle-container">

        <h1 className="titulo">Detalle de Orden</h1>

        {/* ENCABEZADO */}
        <div className="detalle-header">

          <div className="detalle-item">
            <label>Código:</label>
            <span>{ot.codigo || ot.id}</span> {/* Usamos .codigo si existe */}
          </div>

          <div className="detalle-item">
            <label>Nombre/Título:</label>
            <span>{ot.titulo || ot.nombre}</span>
          </div>

          <div className="detalle-item">
            <label>Estado:</label>
            <span>{ot.estado}</span>
          </div>

          <div className="detalle-item">
            <label>Fecha Inicio:</label>
            <span>{ot.fecha_inicio_contrato || ot.fechaInicio}</span>
          </div>

          <div className="detalle-item">
            <label>Cliente:</label>
            <span>{ot.cliente || 'N/A'}</span>
          </div>

          <div className="detalle-item">
            <label>Responsable:</label>
            <span>{ot.nombre_responsable || ot.responsable || 'Sin asignar'}</span>
          </div>

        </div>

        
        <div className="detalle-main">

          
          <div className="datos-box">
            <h3>Datos General</h3>

            <div className="datos-grid">
              <div>
                <label>Descripción:</label>
                <p>{ot.descripcion}</p>
              </div>

              <div>
                <label>F. Estimada Fin:</label>
                <p>{ot.fecha_fin_contrato || ot.fechaFin}</p>
              </div>

              <div>
                <label>Estado Actual:</label>
                <p>{ot.estado}</p>
              </div>
            </div>
          </div>

          
          <div className="recursos-box">
            <h3>Recursos Adjuntos</h3>

            <div className="recursos-grid">
              <div className="rcard">
                <span>Imágenes</span>
                <b>{(ot.imagenes && ot.imagenes.length) || 0}</b>
              </div>

              <div className="rcard">
                <span>Enlaces</span>
                <b>0</b>
              </div>

              <div className="rcard">
                <span>Archivos</span>
                <b>0</b>
              </div>
            </div>
          </div>

        </div>

        
        <div className="botonera">
          {/* 💡 CORRECCIÓN DE NAVEGACIÓN: Asegúrate de que el ID de la OT sea correcto */}
          <button onClick={() => navigate(`/ModificarOT/${ot.id_ot || ot.id}`)}>Configurar OT</button>
          <button>Agregar Recursos</button>
          <button>Exportar PDF</button>
          <button>Exportar CSV</button>
          {/* 💡 CORRECCIÓN DE NAVEGACIÓN: Usar template string correctamente */}
          <button onClick={() => navigate(`/listaOT/${usuario ? usuario.id : ''}`)}>Inicio</button> 
        </div>

        
        <div className="historial-box">
          <h3>Historial de Actualizaciones</h3>

          <table>
            <thead>
              <tr>
                <th>Fecha</th>
                <th>Descripción</th>
                <th>Responsable</th>
              </tr>
            </thead>

            <tbody>
              {/* Manejo de historial nulo o vacío */}
              {(ot.historial || []).map((h, i) => (
                <tr key={i}>
                  <td>{h.fecha}</td>
                  <td>{h.msg}</td>
                  <td>{ot.responsable || h.responsable_nombre || 'N/A'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        
        <div className="comentarios-box">
          <h3>Comentarios</h3>

          <ul>
            {/* Manejo de comentarios nulo o vacío */}
            {(ot.comentarios || []).map((c, i) => (
              <li key={i}>
                <b>{c.autor}:</b> {c.texto}
              </li>
            ))}
          </ul>

          <button className="btn-add">+</button>
        </div>

      </div>

      <Footer />
    </>
  );
}