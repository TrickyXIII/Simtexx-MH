import React, { useState, useEffect, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import NavBar from "../components/NavBar";
import Footer from "../components/Footer";
import { getOTs } from '../services/otService'; 
// Asegúrate de que este archivo exista:
// import "./ListaOT.css"; 

const getResponsables = () => {
    // ESTA FUNCIÓN DEBE CARGAR DATOS REALES DE TU API DE USUARIOS
    return [
        { id: 'Todos', nombre: 'Responsable: Todos' },
        { id: 3003, nombre: 'Admin (3003)' }, 
        { id: 1010, nombre: 'Juan Pérez (1010)' }, 
    ];
};

export default function ListaOT() { 
    const navigate = useNavigate();
    
    // --- ESTADOS ---
    const [ots, setOts] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null); 
    const [estadoFiltro, setEstadoFiltro] = useState('Todos');
    const [responsableFiltro, setResponsableFiltro] = useState('Todos'); 
    const [nombreCodigoFiltro, setNombreCodigoFiltro] = useState('');
    const [fechaDesde, setFechaDesde] = useState('');
    const [fechaHasta, setFechaHasta] = useState('');
    
    const estados = ['Todos', 'Pendiente', 'En Proceso', 'Finalizada']; 
    const responsables = getResponsables();

    const cargarOTs = useCallback(async () => {
        setLoading(true);
        setError(null); 
        const filtros = {
            estado: estadoFiltro,
            responsable_id: responsableFiltro,
            nombre_cliente_codigo: nombreCodigoFiltro,
            fechaDesde: fechaDesde,
            fechaHasta: fechaHasta,
        };
        
        try {
            // Se asume que getOTs(filtros) llama correctamente a tu API Back-end
            const data = await getOTs(filtros); 
            setOts(data);
        } catch (err) {
            console.error('Fallo al cargar OTs:', err);
            setError("Error al cargar las Órdenes de Trabajo. Verifica la conexión con el Back-end.");
            setOts([]); 
        } finally {
            setLoading(false);
        }
    }, [estadoFiltro, responsableFiltro, nombreCodigoFiltro, fechaDesde, fechaHasta]);

    useEffect(() => {
        cargarOTs();
    }, [cargarOTs]); 

    const limpiarFiltros = () => {
        setEstadoFiltro('Todos');
        setResponsableFiltro('Todos');
        setNombreCodigoFiltro('');
        setFechaDesde('');
        setFechaHasta('');
    };
    
    // 💡 FUNCIÓN DE NAVEGACIÓN DIRECTA AL DETALLE/EDICIÓN
    const handleEditClick = (otId) => {
        // La URL ya está en el código, solo la encapsulamos para claridad:
        navigate(`/detalleot/${otId}`);
    };

    // Cálculos de resumen
    const totalOT = ots.length;
    const pendientes = ots.filter(ot => ot.estado === 'Pendiente').length;
    const enProceso = ots.filter(ot => ot.estado === 'En Proceso').length; 
    const finalizadas = ots.filter(ot => ot.estado === 'Finalizada').length;


    // --- RENDERIZADO PRINCIPAL ---
    return (
        <>
            <NavBar/>
            <div style={{ padding: '20px' }}>
                <h2>Gestión de OTS</h2>
                
                {/* BOTONES DE ACCIÓN */}
                <div style={{ marginBottom: '20px' }}>
                    <button onClick={() => navigate("/crearot")} style={{ marginRight: '10px' }}>Crear OT</button>
                    <button style={{ marginRight: '10px' }}>Exportar (PDF)</button>
                    <button style={{ marginRight: '10px' }}>Exportar (CSV)</button>
                    <button onClick={() => navigate("/inicio")}>Inicio</button>
                </div>

                {/* Mensaje de Error (visible solo si la API falla) */}
                {error && (
                    <div style={{ color: 'red', padding: '15px', border: '1px solid red', borderRadius: '5px', marginBottom: '20px' }}>
                        {error}
                    </div>
                )}

                {/* Mensaje de Carga (visible mientras loading es true) */}
                {loading && !error && (
                    <div style={{ textAlign: 'center', padding: '50px' }}>
                        <h3>Cargando Órdenes de Trabajo...</h3>
                        <p>Verificando el Back-end (puerto 4000) y obteniendo datos.</p>
                    </div>
                )}

                {/* Contenido Principal (filtros, tabla, paneles) */}
                {!loading && !error && (
                    <>
                        {/* FILTROS DE BÚSQUEDA (Esto es lo que estabas viendo) */}
                        <div style={{ 
                            display: 'flex', 
                            flexWrap: 'wrap', 
                            gap: '10px', 
                            marginBottom: '20px',
                            padding: '15px',
                            border: '1px solid #ddd',
                            borderRadius: '8px'
                        }}>
                            <input
                                type="text"
                                placeholder="Nombre Cliente / Código"
                                value={nombreCodigoFiltro}
                                onChange={(e) => setNombreCodigoFiltro(e.target.value)}
                                style={{ padding: '8px', border: '1px solid #ccc', borderRadius: '4px' }}
                            />
                            
                            <select
                                value={estadoFiltro}
                                onChange={(e) => setEstadoFiltro(e.target.value)}
                                style={{ padding: '8px', border: '1px solid #ccc', borderRadius: '4px' }}
                            >
                                {estados.map(estado => (
                                    <option key={estado} value={estado}>{estado}</option>
                                ))}
                            </select>

                            <select
                                value={responsableFiltro}
                                onChange={(e) => setResponsableFiltro(e.target.value)}
                                style={{ padding: '8px', border: '1px solid #ccc', borderRadius: '4px' }}
                            >
                                {responsables.map(r => (
                                    <option key={r.id} value={r.id}>{r.nombre}</option>
                                ))}
                            </select>

                            <input
                                type="date"
                                value={fechaDesde}
                                onChange={(e) => setFechaDesde(e.target.value)}
                                style={{ padding: '8px', border: '1px solid #ccc', borderRadius: '4px' }}
                            />
                            
                            <input
                                type="date"
                                value={fechaHasta}
                                onChange={(e) => setFechaHasta(e.target.value)}
                                style={{ padding: '8px', border: '1px solid #ccc', borderRadius: '4px' }}
                            />

                            <button 
                                onClick={limpiarFiltros} 
                                style={{ padding: '8px 15px', background: '#dc3545', color: 'white', border: 'none', borderRadius: '4px' }}
                            >
                                Limpiar Filtros
                            </button>
                        </div>


                        {/* TABLA DE DATOS */}
                        <div style={{ display: 'grid', gridTemplateColumns: '3fr 1fr', gap: '20px' }}>
                            <table
                                style={{
                                    width: "100%",
                                    borderCollapse: "collapse",
                                    backgroundColor: 'white',
                                    borderRadius: '8px',
                                    boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
                                }}
                            >
                                <thead>
                                    <tr style={{ backgroundColor: '#f8f9fa' }}>
                                        <th style={{ borderBottom: "1px solid #ccc", padding: '12px' }}>Título/Descripción Breve</th>
                                        <th style={{ borderBottom: "1px solid #ccc", padding: '12px' }}>Responsable</th>
                                        <th style={{ borderBottom: "1px solid #ccc", padding: '12px' }}>Estado</th>
                                        <th style={{ borderBottom: "1px solid #ccc", padding: '12px' }}>Acciones</th>
                                    </tr>
                                </thead>

                                <tbody>
                                    {ots.length === 0 ? (
                                        <tr>
                                            <td colSpan="4" style={{ textAlign: "center", padding: "20px" }}>
                                                No se encontraron Órdenes de Trabajo con los filtros actuales.
                                            </td>
                                        </tr>
                                    ) : (
                                        ots.map((ot) => (
                                            <tr key={ot.id_ot}> 
                                                <td style={{ padding: '12px', borderBottom: '1px solid #eee' }}>{ot.titulo}</td>
                                                <td style={{ padding: '12px', borderBottom: '1px solid #eee' }}>{ot.nombre_responsable}</td> 
                                                <td style={{ padding: '12px', borderBottom: '1px solid #eee' }}>{ot.estado}</td>
                                                <td style={{ padding: '12px', borderBottom: '1px solid #eee' }}>
                                                    {/* 💡 CORRECCIÓN DE LA LLAMADA DE ACCIÓN */}
                                                    <button onClick={() => handleEditClick(ot.id_ot)}>Ver / Editar</button>
                                                </td>
                                            </tr>
                                        ))
                                    )}
                                </tbody>
                            </table>

                            {/* PANEL LATERAL DE REGISTROS */}
                            <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                                <h3 style={{ margin: 0 }}>Registros</h3>
                                <div style={{ padding: '15px', borderRadius: '8px', background: 'white', borderLeft: '5px solid black', boxShadow: '0 2px 4px rgba(0,0,0,0.05)' }}>
                                    Total OT: <span style={{ fontSize: '1.5em', fontWeight: 'bold' }}>{totalOT}</span>
                                </div>
                                <div style={{ padding: '15px', borderRadius: '8px', background: 'white', borderLeft: '5px solid blue', boxShadow: '0 2px 4px rgba(0,0,0,0.05)' }}>
                                    Pendientes: <span style={{ fontSize: '1.5em', fontWeight: 'bold' }}>{pendientes}</span>
                                </div>
                                <div style={{ padding: '15px', borderRadius: '8px', background: 'white', borderLeft: '5px solid green', boxShadow: '0 2px 4px rgba(0,0,0,0.05)' }}>
                                    En proceso: <span style={{ fontSize: '1.5em', fontWeight: 'bold' }}>{enProceso}</span>
                                </div>
                                <div style={{ padding: '15px', borderRadius: '8px', background: 'white', borderLeft: '5px solid red', boxShadow: '0 2px 4px rgba(0,0,0,0.05)' }}>
                                    Finalizadas: <span style={{ fontSize: '1.5em', fontWeight: 'bold' }}>{finalizadas}</span>
                                </div>
                            </div>
                        </div>
                    </>
                )}
            </div>
            <Footer/>
        </>
    );
}