// frontend/src/components/NavBar.jsx - CÓDIGO FUNCIONAL MÍNIMO

import React from 'react';
import { useNavigate } from 'react-router-dom'; // Se necesita para la navegación

export default function NavBar() {
    const navigate = useNavigate();
    
    return (
        <header style={{ 
            backgroundColor: '#333', 
            color: 'white', 
            padding: '15px', 
            display: 'flex', 
            justifyContent: 'space-between',
            alignItems: 'center'
        }}>
            <h1 style={{ margin: 0 }}>Simtexx SPA</h1>
            
            {/* Botón de cierre de sesión de prueba */}
            <button 
                onClick={() => {
                    // Limpiar sesión (ejemplo)
                    localStorage.removeItem('usuarioActual');
                    navigate('/'); // Ir a la página de login
                }} 
                style={{ 
                    backgroundColor: 'red', 
                    color: 'white', 
                    padding: '8px 15px', 
                    border: 'none', 
                    borderRadius: '4px',
                    cursor: 'pointer'
                }}
            >
                Cerrar sesión
            </button>
        </header>
    );
}