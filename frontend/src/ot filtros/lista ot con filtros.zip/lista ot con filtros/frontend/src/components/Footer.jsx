// frontend/src/components/Footer.jsx - CÓDIGO FUNCIONAL MÍNIMO

import React from 'react';

export default function Footer() {
    return (
        <footer style={{ 
            backgroundColor: '#222', 
            color: '#aaa', 
            textAlign: 'center', 
            padding: '10px 0',
            position: 'fixed',
            bottom: 0,
            width: '100%',
            fontSize: '0.8em'
        }}>
            <p>© Desarrollado por Inacap Students</p>
        </footer>
    );
}