// frontend/src/App.jsx
import React from 'react';
import AppRoutes from "./routes"; // Importa la definición de tus rutas

export default function App() {
  // Simplemente renderiza la definición de tus rutas
  return <AppRoutes />; 
}