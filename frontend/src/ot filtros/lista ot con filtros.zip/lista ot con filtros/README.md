# Simtexx
Proyecto Simtexx

para iniciar proyecto =>

1) Clonar el repositorio

git clone ...



(2) Crear su propio .env en backend: 

PORT=4000

DATA_BASEURL= esto sera enviado por wsp




(3) Instalar dependencias y correr backend + frontend

Backend:


cd backend

npm install

npm run dev


Frontend:


cd frontend

npm install

npm run dev





para las modificaciones desde el frontend se debe usar el build:

1.- modificar su tarea y guardar (todo esto en el frontend)

2.- en el cdm con ruta a la carpeta frontend : npm run build

3.- se crea la carpeta dist/ copiar y pegar en el backend -> carpeta frontend

4.- probar npm run dev en el backend. 

¡¡NOTA SOLO CUANDO ESTA COMPLETA LA TAREA TODO SE PUEDE DEPURAR DESDE EL LOCALHOST:5173 !!
